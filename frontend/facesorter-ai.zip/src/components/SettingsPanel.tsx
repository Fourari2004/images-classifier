/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  Scan, 
  FolderTree, 
  Cpu, 
  Eye, 
  Save, 
  HelpCircle 
} from 'lucide-react';
import { Settings } from '../types';

interface SettingsPanelProps {
  id: string;
  settings: Settings;
  onSave: (settings: Settings) => void;
}

export default function SettingsPanel({ id, settings, onSave }: SettingsPanelProps) {
  const handleToggle = (key: keyof Settings) => {
    onSave({ ...settings, [key]: !settings[key] });
  };

  const handleSelectChange = (key: keyof Settings, value: string | number) => {
    onSave({ ...settings, [key]: value });
  };

  return (
    <div id={id} className="max-w-4xl mx-auto space-y-8">
      {/* SECTION 1: Facial Recognition Algorithm parameters */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <Scan className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Reconnaissance Faciale</h3>
            <p className="text-xs text-slate-400 font-medium">Ajustez le modèle de deep-learning et le seuil de décision</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Model selection */}
          <div className="space-y-2">
            <label htmlFor="settings-model" className="block text-xs font-bold text-slate-500 uppercase flex items-center gap-1.5">
              Modèle d'extraction facial
            </label>
            <select
              id="settings-model"
              value={settings.modelName}
              onChange={(e) => handleSelectChange('modelName', e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:border-blue-500 text-sm bg-white font-semibold"
            >
              <option value="FaceNet-ResNet50v2">FaceNet-ResNet50v2 (Recommandé)</option>
              <option value="VGG-Face">VGG-Face (Précision standard)</option>
              <option value="InsightFace-r100">InsightFace-r100 (Haute précision)</option>
              <option value="MTCNN-DenseNet">MTCNN-DenseNet (Rapide)</option>
            </select>
          </div>

          {/* Min face size */}
          <div className="space-y-2">
            <label htmlFor="settings-min-face" className="block text-xs font-bold text-slate-500 uppercase">
              Taille minimale des visages (pixels)
            </label>
            <input
              id="settings-min-face"
              type="number"
              min="16"
              max="256"
              value={settings.minFaceSize}
              onChange={(e) => handleSelectChange('minFaceSize', parseInt(e.target.value) || 64)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:border-blue-500 text-sm font-semibold"
            />
          </div>

          {/* Slider for confidence */}
          <div className="space-y-2 md:col-span-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase">
              <span>Seuil de confiance minimum</span>
              <span className="font-mono text-blue-600 font-extrabold">{Math.round(settings.confidenceThreshold * 100)}%</span>
            </div>
            <input
              id="settings-confidence-slider"
              type="range"
              min="50"
              max="95"
              value={settings.confidenceThreshold * 100}
              onChange={(e) => handleSelectChange('confidenceThreshold', parseFloat(e.target.value) / 100)}
              className="w-full h-2 bg-slate-100 rounded-lg cursor-pointer accent-blue-600"
            />
            <span className="block text-[10px] text-slate-400">
              Un seuil élevé évite les faux positifs (p. ex. mélanger deux visages similaires) mais peut créer des profils "Inconnus" redondants.
            </span>
          </div>
        </div>
      </div>

      {/* SECTION 2: Files Organizing Strategy */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <FolderTree className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Organisation des Fichiers</h3>
            <p className="text-xs text-slate-400 font-medium">Définissez comment structurer et ordonner vos photos classifiées</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Option: Copy */}
          <button
            id="settings-btn-copy"
            type="button"
            onClick={() => {
              onSave({ ...settings, copyFiles: true, symlinkFiles: false });
            }}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-36 transition-all ${
              settings.copyFiles
                ? 'border-blue-200 bg-blue-50/20 shadow-xs'
                : 'border-slate-100 hover:border-slate-200 bg-white'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
              <span className="text-xs font-bold">1</span>
            </div>
            <div>
              <span className="block text-xs font-bold text-slate-800">Copier les fichiers</span>
              <span className="block text-[10px] text-slate-400 mt-0.5">Duplique l'image originale dans le répertoire de la personne.</span>
            </div>
          </button>

          {/* Option: Symlinks */}
          <button
            id="settings-btn-symlinks"
            type="button"
            onClick={() => {
              onSave({ ...settings, copyFiles: false, symlinkFiles: true });
            }}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-36 transition-all ${
              settings.symlinkFiles
                ? 'border-blue-200 bg-blue-50/20 shadow-xs'
                : 'border-slate-100 hover:border-slate-200 bg-white'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
              <span className="text-xs font-bold">2</span>
            </div>
            <div>
              <span className="block text-xs font-bold text-slate-800">Créer des liens symboliques</span>
              <span className="block text-[10px] text-slate-400 mt-0.5">Crée un pointeur virtuel léger (Recommandé pour préserver l'espace).</span>
            </div>
          </button>

          {/* Option: In-place index only */}
          <button
            id="settings-btn-index-only"
            type="button"
            onClick={() => {
              onSave({ ...settings, copyFiles: false, symlinkFiles: false });
            }}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-36 transition-all ${
              !settings.copyFiles && !settings.symlinkFiles
                ? 'border-blue-200 bg-blue-50/20 shadow-xs'
                : 'border-slate-100 hover:border-slate-200 bg-white'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
              <span className="text-xs font-bold">3</span>
            </div>
            <div>
              <span className="block text-xs font-bold text-slate-800">Indexation seule (En place)</span>
              <span className="block text-[10px] text-slate-400 mt-0.5">Enregistre l'association dans la base de données sans déplacer les fichiers.</span>
            </div>
          </button>
        </div>
      </div>

      {/* SECTION 3: Performance Hardware preferences */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Performances Matérielles</h3>
            <p className="text-xs text-slate-400 font-medium">Optimisez l'allocation des processeurs pour le calcul d'embeddings</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Threads selector */}
          <div className="space-y-2">
            <label htmlFor="settings-threads" className="block text-xs font-bold text-slate-500 uppercase">
              Nombre de threads processeur (CPU)
            </label>
            <select
              id="settings-threads"
              value={settings.threads}
              onChange={(e) => handleSelectChange('threads', parseInt(e.target.value) || 4)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:border-blue-500 text-sm bg-white font-semibold"
            >
              {[1, 2, 4, 8, 12, 16].map((num) => (
                <option key={num} value={num}>
                  {num} {num === 1 ? 'coeur' : 'coeurs'}
                </option>
              ))}
            </select>
          </div>

          {/* GPU accelerated toggle */}
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
            <div className="space-y-0.5">
              <span className="block text-xs font-bold text-slate-800">Accélération GPU (CUDA / OpenCL)</span>
              <span className="block text-[10px] text-slate-400">Active la carte graphique pour multiplier par 5 la vitesse</span>
            </div>
            <button
              id="settings-btn-gpu"
              type="button"
              onClick={() => handleToggle('gpuEnabled')}
              className={`w-11 h-6 rounded-full transition-colors relative focus:outline-hidden ${
                settings.gpuEnabled ? 'bg-blue-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  settings.gpuEnabled ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 4: Appearance & Language */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <Eye className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Apparence & Préférences</h3>
            <p className="text-xs text-slate-400 font-medium">Personnalisez la langue et la mise en page de l'interface</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Language Selector */}
          <div className="space-y-2">
            <label htmlFor="settings-lang" className="block text-xs font-bold text-slate-500 uppercase">
              Langue de l'interface (Language)
            </label>
            <select
              id="settings-lang"
              value={settings.language}
              onChange={(e) => handleSelectChange('language', e.target.value as 'fr' | 'en')}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:border-blue-500 text-sm bg-white font-semibold"
            >
              <option value="fr">Français (French)</option>
              <option value="en">English (Anglais)</option>
            </select>
          </div>

          {/* Thumbnail scale */}
          <div className="space-y-2">
            <label htmlFor="settings-thumbnails" className="block text-xs font-bold text-slate-500 uppercase">
              Taille des miniatures
            </label>
            <select
              id="settings-thumbnails"
              value={settings.thumbnailSize}
              onChange={(e) => handleSelectChange('thumbnailSize', e.target.value as 'sm' | 'md' | 'lg')}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:border-blue-500 text-sm bg-white font-semibold"
            >
              <option value="sm">Petite (Dense)</option>
              <option value="md">Moyenne (Standard)</option>
              <option value="lg">Grande (Confortable)</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
