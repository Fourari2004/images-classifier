/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  LayoutDashboard, 
  ScanLine, 
  Users, 
  Image, 
  Activity, 
  History, 
  Settings, 
  Cpu 
} from 'lucide-react';
import { ActiveTab } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  serverStatus: 'online' | 'offline';
}

export default function Sidebar({ activeTab, onTabChange, serverStatus }: SidebarProps) {
  // Normalize detail tab back to 'people' for menu selection highlighting
  const currentMenuTab = activeTab === 'person-detail' ? 'people' : activeTab;

  const menuItems = [
    { id: 'dashboard' as ActiveTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'scanner' as ActiveTab, label: 'Scanner', icon: ScanLine },
    { id: 'people' as ActiveTab, label: 'Personnes', icon: Users },
    { id: 'gallery' as ActiveTab, label: 'Galerie', icon: Image },
    { id: 'processing' as ActiveTab, label: 'Traitements / Historique', icon: History },
    { id: 'settings' as ActiveTab, label: 'Paramètres', icon: Settings },
  ];

  return (
    <aside id="sidebar-root" className="w-64 bg-white border-r border-slate-200 flex flex-col h-screen shrink-0 sticky top-0">
      {/* Brand Logo */}
      <div className="p-6 border-b border-slate-100 flex items-center gap-3">
        <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-500/20">
          <ScanLine className="w-5 h-5" />
        </div>
        <div>
          <span className="font-sans font-extrabold text-slate-900 tracking-tight text-base block leading-tight">
            FaceSorter AI
          </span>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Automatic Sorting
          </span>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav id="sidebar-nav" className="flex-1 p-4 space-y-1 overflow-y-auto">
        <span className="block px-3 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2">
          Menu Principal
        </span>
        
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentMenuTab === item.id;
          
          return (
            <button
              key={item.id}
              id={`sidebar-item-${item.id}`}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold tracking-tight transition-all text-left ${
                isActive
                  ? 'bg-blue-50 text-blue-600 shadow-inner'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50/80'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
              <span className="flex-1">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Sidebar Footer */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50 space-y-2">
        <div className="flex items-center justify-between text-[11px] font-medium text-slate-400">
          <span>Version</span>
          <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded-md font-semibold text-slate-600">
            v1.2.0
          </span>
        </div>

        {/* Server Status Indicator */}
        <div className="flex items-center justify-between text-[11px] font-medium text-slate-500">
          <span className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-slate-400" /> API Server
          </span>
          <div className="flex items-center gap-1">
            <span className={`w-2 h-2 rounded-full ${serverStatus === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
            <span className="capitalize text-slate-700 font-semibold text-[10px]">
              {serverStatus === 'online' ? 'en ligne' : 'hors ligne'}
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
