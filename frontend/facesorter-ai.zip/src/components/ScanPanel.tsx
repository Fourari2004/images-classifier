/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Folder, 
  UploadCloud, 
  Sliders, 
  Layers, 
  Copy, 
  Link2, 
  RefreshCw, 
  Play, 
  FileImage, 
  TrendingUp, 
  Users, 
  Smile, 
  CheckCircle2, 
  Clock 
} from 'lucide-react';
import { FOLDERS_TO_SCAN, UNSCANNED_PHOTOS_BY_FOLDER, UnscannedPhoto } from '../data/mockData';
import { Settings } from '../types';

interface ScanPanelProps {
  id: string;
  settings: Settings;
  onUpdateSettings: (settings: Settings) => void;
  onStartScan: (folderPath: string, photosCount: number, photos: UnscannedPhoto[]) => void;
  isScanning: boolean;
  scanProgress: number;
  scanStatus: {
    analyzedCount: number;
    totalCount: number;
    currentPhotoUrl?: string;
    currentPhotoName?: string;
    detectedFacesCount: number;
    recognizedPeopleCount: number;
    elapsedTime: string;
  };
}

export default function ScanPanel({
  id,
  settings,
  onUpdateSettings,
  onStartScan,
  isScanning,
  scanProgress,
  scanStatus
}: ScanPanelProps) {
  const [selectedFolder, setSelectedFolder] = useState(FOLDERS_TO_SCAN[0].path);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeFolderData = FOLDERS_TO_SCAN.find((f) => f.path === selectedFolder);
  const pendingPhotos = UNSCANNED_PHOTOS_BY_FOLDER[selectedFolder] || [];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    // Simulate drop folders
  };

  const triggerAnalysis = () => {
    onStartScan(selectedFolder, pendingPhotos.length, pendingPhotos);
  };

  return (
    <div id={id} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Parameters & Folder Selectors Column (2 Columns wide if not scanning) */}
      <div className={`space-y-6 ${isScanning ? 'lg:col-span-1' : 'lg:col-span-2'}`}>
        {/* Main Folder Selection Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
              <Folder className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Source de numérisation</h3>
              <p className="text-xs text-slate-400 font-medium">Sélectionnez le répertoire à scanner pour identifier les personnes</p>
            </div>
          </div>

          {/* Folder Select Dropdown */}
          <div className="space-y-2">
            <label htmlFor="folder-select" className="block text-xs font-bold text-slate-500 uppercase">
              Dossier cible local
            </label>
            <select
              id="folder-select"
              value={selectedFolder}
              disabled={isScanning}
              onChange={(e) => setSelectedFolder(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:border-blue-500 text-sm bg-white font-medium"
            >
              {FOLDERS_TO_SCAN.map((folder) => (
                <option key={folder.path} value={folder.path}>
                  {folder.path} ({folder.count} photos) — {folder.description}
                </option>
              ))}
            </select>
          </div>

          {/* Simulated Drag & Drop Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all ${
              isDragging
                ? 'border-blue-500 bg-blue-50/20'
                : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
            } ${isScanning ? 'opacity-50 pointer-events-none' : ''}`}
          >
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs mb-3 text-slate-400 group-hover:text-slate-600">
              <UploadCloud className="w-6 h-6 text-slate-400" />
            </div>
            <h4 className="text-xs font-bold text-slate-800">Glisser-déposer un dossier d'images</h4>
            <p className="text-[10px] text-slate-400 max-w-xs mt-1 mb-4">
              Sélectionnez ou glissez un répertoire d'images complet pour lancer une classification par lot
            </p>
            <button
              id="btn-trigger-upload"
              onClick={() => fileInputRef.current?.click()}
              disabled={isScanning}
              className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 shadow-xs transition-colors"
            >
              Choisir un dossier
            </button>
            <input id="hidden-file-input" ref={fileInputRef} type="file" className="hidden" multiple webkitdirectory="" directory="" />
          </div>
        </div>

        {/* Scan Parameters Settings Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Paramètres du traitement</h3>
              <p className="text-xs text-slate-400 font-medium">Ajustez la sensibilité de l'algorithme de détection</p>
            </div>
          </div>

          <div className="space-y-5">
            {/* Similarity threshold slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase">
                <span>Seuil de similarité faciale (Threshold)</span>
                <span className="font-mono text-blue-600 text-sm font-extrabold">
                  {Math.round(settings.confidenceThreshold * 100)}%
                </span>
              </div>
              <input
                id="threshold-range"
                type="range"
                min="50"
                max="95"
                value={settings.confidenceThreshold * 100}
                disabled={isScanning}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, confidenceThreshold: parseFloat(e.target.value) / 100 })
                }
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                <span>Tolérant (Plus de regroupements)</span>
                <span>Strict (Moins d'erreurs)</span>
              </div>
            </div>

            {/* Checkboxes Options */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-100 pt-5">
              {/* Copy Files */}
              <label
                id="label-copy-files"
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                  settings.copyFiles
                    ? 'border-blue-100 bg-blue-50/20 text-blue-900'
                    : 'border-slate-100 bg-white text-slate-700'
                } ${isScanning ? 'opacity-50 pointer-events-none' : ''}`}
              >
                <input
                  id="checkbox-copy-files"
                  type="checkbox"
                  checked={settings.copyFiles}
                  disabled={isScanning}
                  onChange={(e) => onUpdateSettings({ ...settings, copyFiles: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <div className="space-y-0.5">
                  <span className="text-xs font-bold flex items-center gap-1.5">
                    <Copy className="w-3.5 h-3.5 shrink-0" /> Créer des copies
                  </span>
                  <span className="block text-[10px] text-slate-400">Duplique physiquement</span>
                </div>
              </label>

              {/* Symlinks */}
              <label
                id="label-symlinks"
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                  settings.symlinkFiles
                    ? 'border-blue-100 bg-blue-50/20 text-blue-900'
                    : 'border-slate-100 bg-white text-slate-700'
                } ${isScanning ? 'opacity-50 pointer-events-none' : ''}`}
              >
                <input
                  id="checkbox-symlinks"
                  type="checkbox"
                  checked={settings.symlinkFiles}
                  disabled={isScanning}
                  onChange={(e) => onUpdateSettings({ ...settings, symlinkFiles: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <div className="space-y-0.5">
                  <span className="text-xs font-bold flex items-center gap-1.5">
                    <Link2 className="w-3.5 h-3.5 shrink-0" /> Liens symboliques
                  </span>
                  <span className="block text-[10px] text-slate-400">Évite la duplication</span>
                </div>
              </label>

              {/* Auto-Merge */}
              <label
                id="label-auto-merge"
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                  settings.autoMerge
                    ? 'border-blue-100 bg-blue-50/20 text-blue-900'
                    : 'border-slate-100 bg-white text-slate-700'
                } ${isScanning ? 'opacity-50 pointer-events-none' : ''}`}
              >
                <input
                  id="checkbox-auto-merge"
                  type="checkbox"
                  checked={settings.autoMerge}
                  disabled={isScanning}
                  onChange={(e) => onUpdateSettings({ ...settings, autoMerge: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <div className="space-y-0.5">
                  <span className="text-xs font-bold flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 shrink-0" /> Fusion auto.
                  </span>
                  <span className="block text-[10px] text-slate-400">Regroupe automatiquement</span>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Lancer l'analyse action button */}
        {!isScanning && (
          <button
            id="btn-start-analysis"
            onClick={triggerAnalysis}
            disabled={pendingPhotos.length === 0}
            className="w-full py-4 rounded-2xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-extrabold text-sm shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" /> Lancer l'analyse faciale ({pendingPhotos.length} photos)
          </button>
        )}
      </div>

      {/* Right Column: List of Images (If not scanning) OR Live Progress Panel (If scanning) */}
      <div className={`${isScanning ? 'lg:col-span-2' : 'lg:col-span-1'}`}>
        <AnimatePresence mode="wait">
          {!isScanning ? (
            <motion.div
              key="pending-list"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs h-full flex flex-col justify-between min-h-[300px]"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                    Fichiers à traiter ({pendingPhotos.length})
                  </h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full">
                    Prêt
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[400px] overflow-y-auto pr-1">
                  {pendingPhotos.map((photo) => (
                    <div
                      key={photo.id}
                      className="flex items-center gap-3 p-2 bg-slate-50 rounded-xl border border-slate-100 hover:bg-slate-100/55 transition-colors"
                    >
                      <img
                        src={photo.url}
                        alt={photo.name}
                        className="w-10 h-10 object-cover rounded-lg border border-slate-200"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="block text-xs font-bold text-slate-800 truncate">{photo.name}</span>
                        <span className="block text-[10px] text-slate-400 font-medium">{photo.size}</span>
                      </div>
                      <FileImage className="w-4 h-4 text-slate-400 shrink-0" />
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 text-[10px] text-slate-400 font-medium leading-relaxed">
                Les photos de ce dossier local seront indexées dans la base de données après détection de caractéristiques faciales.
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="active-progress"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="bg-white p-6 rounded-3xl border border-blue-200 shadow-xl space-y-6"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2">
                  <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />
                  <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">Analyse en cours...</h3>
                </div>
                <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full">
                  {scanProgress}%
                </span>
              </div>

              {/* Progress Bar */}
              <div className="space-y-2">
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${scanProgress}%` }}
                    className="bg-blue-600 h-full rounded-full"
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                  <span>Photo {scanStatus.analyzedCount} sur {scanStatus.totalCount}</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" /> {scanStatus.elapsedTime}
                  </span>
                </div>
              </div>

              {/* Current photo processed preview */}
              {scanStatus.currentPhotoUrl && (
                <div className="space-y-3">
                  <span className="block text-xs font-bold text-slate-500 uppercase">Image active :</span>
                  <div className="relative aspect-video max-h-52 rounded-xl overflow-hidden bg-slate-950 border border-slate-100">
                    <img
                      src={scanStatus.currentPhotoUrl}
                      alt="Active"
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                    />

                    {/* Simulated live scanner horizontal line */}
                    <motion.div
                      animate={{ top: ['0%', '100%', '0%'] }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                      className="absolute left-0 right-0 h-0.5 bg-blue-400/80 shadow-[0_0_10px_#60a5fa] z-10"
                    />

                    {/* Bounding Box Drawing Box dynamically if progress state is active */}
                    <div className="absolute left-[35%] top-[20%] w-[30%] h-[30%] border-2 border-dashed border-blue-400 rounded-lg animate-pulse bg-blue-500/10">
                      <div className="absolute top-1 left-1 bg-blue-600 text-white text-[8px] px-1 py-0.5 rounded font-extrabold uppercase">
                        Visage detecté
                      </div>
                    </div>
                  </div>
                  <p className="text-xs font-semibold text-slate-600 text-center truncate">
                    {scanStatus.currentPhotoName}
                  </p>
                </div>
              )}

              {/* Dynamic stats counters */}
              <div className="grid grid-cols-3 gap-3 border-t border-slate-100 pt-5">
                {/* Analysed count */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <Smile className="w-5 h-5 text-slate-400 mx-auto mb-1" />
                  <span className="block text-[9px] font-bold text-slate-400 uppercase">Analysées</span>
                  <span className="text-xs font-extrabold text-slate-800">
                    {scanStatus.analyzedCount} / {scanStatus.totalCount}
                  </span>
                </div>

                {/* Faces Detected */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <TrendingUp className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                  <span className="block text-[9px] font-bold text-slate-400 uppercase">Visages</span>
                  <span className="text-xs font-extrabold text-slate-800">{scanStatus.detectedFacesCount}</span>
                </div>

                {/* Recognized */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <Users className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
                  <span className="block text-[9px] font-bold text-slate-400 uppercase">Profils</span>
                  <span className="text-xs font-extrabold text-slate-800">{scanStatus.recognizedPeopleCount}</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
