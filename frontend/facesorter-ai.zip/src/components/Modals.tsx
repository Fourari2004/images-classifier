/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, GitMerge, Edit3, Play, Folder, Users, AlertCircle } from 'lucide-react';
import { Person } from '../types';

// Modal Wrapper for common overlay and animation
interface ModalWrapperProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

function ModalWrapper({ isOpen, onClose, children }: ModalWrapperProps) {
  // Close on Esc key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', stiffness: 350, damping: 25 }}
            className="relative bg-white w-full max-w-md rounded-2xl border border-slate-200 shadow-2xl p-6 overflow-hidden z-10 pointer-events-auto"
          >
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

// Rename Person Modal
interface RenamePersonModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentName: string;
  onConfirm: (newName: string) => void;
}

export function RenamePersonModal({ isOpen, onClose, currentName, onConfirm }: RenamePersonModalProps) {
  const [name, setName] = useState(currentName);

  useEffect(() => {
    setName(currentName);
  }, [currentName, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onConfirm(name.trim());
      onClose();
    }
  };

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose}>
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <Edit3 className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-bold text-slate-900">Renommer la personne</h3>
        </div>
        <button id="modal-rename-close" onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-50">
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="rename-input" className="block text-xs font-semibold text-slate-500 uppercase mb-2">
            Nouveau nom de la personne
          </label>
          <input
            id="rename-input"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Sophie Martin"
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm"
            autoFocus
          />
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            id="modal-rename-cancel"
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 font-medium text-slate-700 text-sm transition-colors"
          >
            Annuler
          </button>
          <button
            id="modal-rename-submit"
            type="submit"
            disabled={!name.trim()}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-xs transition-colors"
          >
            Enregistrer
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
}

// Merge People Modal
interface MergePeopleModalProps {
  isOpen: boolean;
  onClose: () => void;
  person: Person | null;
  allPeople: Person[];
  onConfirm: (targetPersonId: string) => void;
}

export function MergePeopleModal({ isOpen, onClose, person, allPeople, onConfirm }: MergePeopleModalProps) {
  const [targetId, setTargetId] = useState('');

  useEffect(() => {
    if (isOpen) setTargetId('');
  }, [isOpen]);

  if (!person) return null;

  // Filter out the person itself from target candidates
  const candidates = allPeople.filter((p) => p.id !== person.id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (targetId) {
      onConfirm(targetId);
      onClose();
    }
  };

  const targetPerson = candidates.find((p) => p.id === targetId);

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose}>
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <GitMerge className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-bold text-slate-900 font-sans">Fusionner des profils</h3>
        </div>
        <button id="modal-merge-close" onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-50">
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <p className="text-xs text-slate-500">
          Toutes les photos associées à <strong className="text-slate-800">{person.name}</strong> seront transférées vers le profil cible. Ce profil sera ensuite supprimé.
        </p>

        {/* Source Person */}
        <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
          <img
            src={person.avatarUrl}
            alt={person.name}
            className="w-10 h-10 rounded-full object-cover border border-white shadow-xs"
            referrerPolicy="no-referrer"
          />
          <div>
            <div className="text-xs text-slate-400 uppercase font-bold">Fusionner</div>
            <div className="text-sm font-bold text-slate-800">{person.name}</div>
          </div>
        </div>

        {/* Select Target */}
        <div>
          <label htmlFor="merge-target" className="block text-xs font-semibold text-slate-500 uppercase mb-2">
            Vers le profil de :
          </label>
          <select
            id="merge-target"
            value={targetId}
            onChange={(e) => setTargetId(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm bg-white"
          >
            <option value="">Sélectionner une personne...</option>
            {candidates.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.photosCount} photos)
              </option>
            ))}
          </select>
        </div>

        {targetPerson && (
          <div className="flex items-center gap-3 p-3 bg-blue-50/50 rounded-xl border border-blue-100/50">
            <img
              src={targetPerson.avatarUrl}
              alt={targetPerson.name}
              className="w-10 h-10 rounded-full object-cover border border-white shadow-xs"
              referrerPolicy="no-referrer"
            />
            <div>
              <div className="text-xs text-blue-500 uppercase font-bold">Profil principal cible</div>
              <div className="text-sm font-bold text-blue-900">{targetPerson.name}</div>
            </div>
          </div>
        )}

        <div className="flex justify-end gap-3 pt-2">
          <button
            id="modal-merge-cancel"
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 font-medium text-slate-700 text-sm transition-colors"
          >
            Annuler
          </button>
          <button
            id="modal-merge-submit"
            type="submit"
            disabled={!targetId}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-xs transition-colors flex items-center gap-1.5"
          >
            <GitMerge className="w-4 h-4" /> Fusionner
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
}

// Delete Confirm Modal
interface DeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemName: string;
  itemType: 'person' | 'photo' | 'association';
  onConfirm: () => void;
}

export function DeleteConfirmModal({ isOpen, onClose, itemName, itemType, onConfirm }: DeleteConfirmModalProps) {
  const getTitles = () => {
    switch (itemType) {
      case 'person':
        return {
          title: 'Supprimer le profil',
          desc: `Êtes-vous sûr de vouloir supprimer le profil de ${itemName} ? Les photos ne seront pas supprimées de votre disque, mais l'association faciale sera réinitialisée.`,
          button: 'Supprimer le profil'
        };
      case 'photo':
        return {
          title: 'Supprimer la photo',
          desc: `Êtes-vous sûr de vouloir supprimer la photo "${itemName}" ? Cette photo sera également dissociée de toutes les personnes reconnues.`,
          button: 'Supprimer'
        };
      case 'association':
        return {
          title: "Supprimer l'association",
          desc: `Êtes-vous sûr de vouloir dissocier ${itemName} de ce visage ? Le visage sera classé comme "Inconnu".`,
          button: 'Supprimer'
        };
    }
  };

  const { title, desc, button } = getTitles();

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose}>
      <div className="flex items-center gap-2.5 text-rose-600 border-b border-slate-100 pb-4 mb-4">
        <div className="p-1.5 bg-rose-50 rounded-lg">
          <Trash2 className="w-5 h-5" />
        </div>
        <h3 className="text-lg font-bold text-slate-900">{title}</h3>
      </div>

      <div className="space-y-4">
        <p className="text-sm text-slate-500 leading-relaxed">{desc}</p>

        <div className="flex justify-end gap-3 pt-2">
          <button
            id="modal-delete-cancel"
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 font-medium text-slate-700 text-sm transition-colors"
          >
            Annuler
          </button>
          <button
            id="modal-delete-confirm"
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm shadow-xs transition-colors flex items-center gap-1.5"
          >
            {button}
          </button>
        </div>
      </div>
    </ModalWrapper>
  );
}

// Confirm Scan Modal
interface ConfirmScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  folderPath: string;
  photosCount: number;
  onConfirm: () => void;
}

export function ConfirmScanModal({ isOpen, onClose, folderPath, photosCount, onConfirm }: ConfirmScanModalProps) {
  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose}>
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <Play className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-bold text-slate-900">Confirmer le Scan</h3>
        </div>
        <button id="modal-scan-close" onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-50">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-4">
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/50 space-y-3">
          <div className="flex items-start gap-3">
            <Folder className="w-5 h-5 text-slate-400 mt-0.5 shrink-0" />
            <div className="space-y-0.5">
              <span className="text-xs text-slate-400 font-bold uppercase">Dossier cible</span>
              <p className="text-sm font-semibold text-slate-800 break-all">{folderPath}</p>
            </div>
          </div>

          <div className="flex items-start gap-3 border-t border-slate-200/50 pt-3">
            <Users className="w-5 h-5 text-slate-400 mt-0.5 shrink-0" />
            <div className="space-y-0.5">
              <span className="text-xs text-slate-400 font-bold uppercase">Photos à analyser</span>
              <p className="text-sm font-semibold text-slate-800">{photosCount} images détectées</p>
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2.5 text-xs text-amber-700 bg-amber-50 p-3 rounded-xl border border-amber-100">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <p>
            Cette action va lancer l'analyse faciale. Les visages trouvés seront comparés à vos profils existants pour tenter une classification automatique.
          </p>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            id="modal-scan-cancel"
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 font-medium text-slate-700 text-sm transition-colors"
          >
            Annuler
          </button>
          <button
            id="modal-scan-confirm"
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-xs transition-colors flex items-center gap-1.5"
          >
            Lancer le scan
          </button>
        </div>
      </div>
    </ModalWrapper>
  );
}
