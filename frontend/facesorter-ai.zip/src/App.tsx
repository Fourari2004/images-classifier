/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Image as ImageIcon, 
  FolderCheck, 
  Eye, 
  Clock, 
  FolderPlus, 
  ChevronRight, 
  Sparkles, 
  Check, 
  Trash2, 
  ArrowLeft, 
  GitMerge, 
  Edit3, 
  ExternalLink, 
  Move, 
  Folder,
  CheckCircle2,
  ListFilter
} from 'lucide-react';

// Import Types
import { Photo, Person, ScanHistory, Settings, ActiveTab, Face } from './types';

// Import Mock Initial Data
import { 
  INITIAL_PEOPLE, 
  INITIAL_PHOTOS, 
  INITIAL_HISTORY, 
  DEFAULT_SETTINGS,
  UNSCANNED_PHOTOS_BY_FOLDER,
  FOLDERS_TO_SCAN,
  UnscannedPhoto
} from './data/mockData';

// Import Components
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StatsCard from './components/StatsCard';
import PersonCard from './components/PersonCard';
import GalleryCard from './components/GalleryCard';
import PhotoViewer from './components/PhotoViewer';
import ScanPanel from './components/ScanPanel';
import HistoryTable from './components/HistoryTable';
import SettingsPanel from './components/SettingsPanel';
import Toast, { ToastMessage } from './components/Toast';
import { LoadingSkeleton, EmptyState } from './components/Skeletons';
import { 
  RenamePersonModal, 
  MergePeopleModal, 
  DeleteConfirmModal, 
  ConfirmScanModal 
} from './components/Modals';

export default function App() {
  // --- STATE ---
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [people, setPeople] = useState<Person[]>(INITIAL_PEOPLE);
  const [photos, setPhotos] = useState<Photo[]>(INITIAL_PHOTOS);
  const [history, setHistory] = useState<ScanHistory[]>(INITIAL_HISTORY);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);

  // Active Selections / Details
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Skeletons / Simulators
  const [isLoading, setIsLoading] = useState(false);

  // Multi-Photo Selection inside Person Details
  const [selectedPhotoIds, setSelectedPhotoIds] = useState<string[]>([]);

  // Scan simulation states
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanFolder, setScanFolder] = useState('');
  const [scanStatus, setScanStatus] = useState({
    analyzedCount: 0,
    totalCount: 0,
    currentPhotoUrl: '',
    currentPhotoName: '',
    detectedFacesCount: 0,
    recognizedPeopleCount: 0,
    elapsedTime: '0.0s',
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Modals state
  const [modals, setModals] = useState<{
    rename: { isOpen: boolean; person: Person | null };
    merge: { isOpen: boolean; person: Person | null };
    delete: { isOpen: boolean; target: any; type: 'person' | 'photo' | 'association' };
    confirmScan: { isOpen: boolean; folderPath: string; photosCount: number; photosToScan: UnscannedPhoto[] };
  }>({
    rename: { isOpen: false, person: null },
    merge: { isOpen: false, person: null },
    delete: { isOpen: false, target: null, type: 'person' },
    confirmScan: { isOpen: false, folderPath: '', photosCount: 0, photosToScan: [] }
  });

  // --- TOAST HELPER ---
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const newToast: ToastMessage = {
      id: Math.random().toString(),
      message,
      type
    };
    setToasts((prev) => [...prev, newToast]);
    // Auto dismiss after 4 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // --- STATS CALCULATION (useMemo) ---
  const stats = useMemo(() => {
    const totalPhotosCount = photos.length;
    const totalPeopleCount = people.length;
    
    // Sum faces from all photos
    const totalFacesCount = photos.reduce((sum, p) => sum + p.facesCount, 0);
    
    // Count unique folder paths
    const foldersSet = new Set(photos.map((p) => {
      const parts = p.path.split('/');
      parts.pop(); // remove file name
      return parts.join('/');
    }));
    const totalFoldersCount = foldersSet.size;

    // Average treatment speed from history
    const successfulScans = history.filter((h) => h.status === 'success');
    let avgSpeed = '1.2s / photo';
    if (successfulScans.length > 0) {
      const totalPhotos = successfulScans.reduce((sum, h) => sum + h.photosCount, 0);
      // Parse durations (e.g., "18.4s")
      const totalDuration = successfulScans.reduce((sum, h) => {
        const value = parseFloat(h.duration.replace('s', '')) || 0;
        return sum + value;
      }, 0);
      if (totalPhotos > 0) {
        avgSpeed = `${(totalDuration / totalPhotos).toFixed(2)}s / photo`;
      }
    }

    return {
      totalPhotos: totalPhotosCount,
      totalPeople: totalPeopleCount,
      totalFolders: totalFoldersCount,
      totalFaces: totalFacesCount,
      avgSpeed
    };
  }, [photos, people, history]);

  // --- TAB RESET ON CHANGE ---
  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    setSearchQuery('');
    setSelectedPhotoIds([]);
  };

  // --- FILTERED DATA (useMemo) ---
  const filteredPeople = useMemo(() => {
    if (!searchQuery) return people;
    return people.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [people, searchQuery]);

  const filteredPhotos = useMemo(() => {
    if (!searchQuery) return photos;
    return photos.filter(
      (p) => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.path.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [photos, searchQuery]);

  const selectedPerson = useMemo(() => {
    if (!selectedPersonId) return null;
    return people.find((p) => p.id === selectedPersonId) || null;
  }, [people, selectedPersonId]);

  // All photos that contain the selected person
  const personPhotos = useMemo(() => {
    if (!selectedPersonId) return [];
    return photos.filter((photo) => 
      photo.faces.some((f) => f.personId === selectedPersonId)
    );
  }, [photos, selectedPersonId]);

  // --- SCANNER PROCESS SIMULATION ---
  const handleStartScanRequest = (folderPath: string, photosCount: number, photosToScan: UnscannedPhoto[]) => {
    // Open Confirmation Dialog
    setModals((prev) => ({
      ...prev,
      confirmScan: { isOpen: true, folderPath, photosCount, photosToScan }
    }));
  };

  const runScanSimulation = (folderPath: string, photosToScan: UnscannedPhoto[]) => {
    setIsScanning(true);
    setScanProgress(0);
    setScanFolder(folderPath);

    let currentIndex = 0;
    const total = photosToScan.length;
    let facesDetected = 0;
    let peopleRecognized = 0;
    const startTime = Date.now();

    setScanStatus({
      analyzedCount: 0,
      totalCount: total,
      currentPhotoUrl: photosToScan[0].url,
      currentPhotoName: photosToScan[0].name,
      detectedFacesCount: 0,
      recognizedPeopleCount: 0,
      elapsedTime: '0.0s',
    });

    const interval = setInterval(() => {
      if (currentIndex >= total) {
        clearInterval(interval);
        
        // Scan completed!
        const finalDurationSec = ((Date.now() - startTime) / 1000).toFixed(1);
        
        // Append history row
        const newHistoryRow: ScanHistory = {
          id: `h_sim_${Math.random().toString()}`,
          date: new Date().toISOString().replace('T', ' ').substring(0, 16),
          folderPath,
          photosCount: total,
          duration: `${finalDurationSec}s`,
          status: 'success',
          progress: 100,
          detectedFaces: facesDetected,
          recognizedPeople: peopleRecognized
        };

        setHistory((prev) => [newHistoryRow, ...prev]);
        setIsScanning(false);
        showToast(`Scan complété ! ${facesDetected} visages analysés dans "${folderPath}".`, 'success');
        handleTabChange('gallery');
        return;
      }

      const activePhoto = photosToScan[currentIndex];
      const stepFacesCount = activePhoto.facesToDetect.length;
      facesDetected += stepFacesCount;

      // Update current active status
      setScanStatus((prev) => ({
        ...prev,
        analyzedCount: currentIndex + 1,
        currentPhotoUrl: activePhoto.url,
        currentPhotoName: activePhoto.name,
        detectedFacesCount: facesDetected,
        elapsedTime: `${((Date.now() - startTime) / 1000).toFixed(1)}s`
      }));

      // Process each face in this photo and add/update database state
      const processedFaces: Face[] = activePhoto.facesToDetect.map((item, faceIdx) => {
        let finalPersonId = item.personId;

        if (item.personId === 'new') {
          // Check if this new person name already got created during this scan to avoid duplicating
          const existing = people.find((p) => p.name.toLowerCase() === (item.personName || '').toLowerCase());
          if (existing) {
            finalPersonId = existing.id;
            peopleRecognized++;
          } else {
            // Create a brand new Person
            const newPersonId = `p_gen_${Math.random().toString()}`;
            const newPerson: Person = {
              id: newPersonId,
              name: item.personName || `Inconnu #${Math.round(Math.random() * 100)}`,
              avatarUrl: item.avatarUrl,
              photosCount: 1,
              facesCount: 1,
              lastSeen: new Date().toISOString().replace('T', ' ').substring(0, 16)
            };
            setPeople((prev) => [...prev, newPerson]);
            finalPersonId = newPersonId;
            peopleRecognized++;
          }
        } else {
          // Increment existing person count
          setPeople((prev) => 
            prev.map((p) => {
              if (p.id === item.personId) {
                return {
                  ...p,
                  photosCount: p.photosCount + 1,
                  facesCount: p.facesCount + 1,
                  lastSeen: new Date().toISOString().replace('T', ' ').substring(0, 16)
                };
              }
              return p;
            })
          );
          peopleRecognized++;
        }

        return {
          id: `f_sim_${activePhoto.id}_${faceIdx}`,
          photoId: activePhoto.id,
          boundingBox: item.boundingBox,
          personId: finalPersonId,
          confidence: item.confidence,
          croppedUrl: item.avatarUrl
        };
      });

      // Assemble new Photo object
      const newPhotoObj: Photo = {
        id: activePhoto.id,
        url: activePhoto.url,
        name: activePhoto.name,
        date: new Date().toISOString().split('T')[0],
        size: activePhoto.size,
        facesCount: stepFacesCount,
        path: `${folderPath}/${activePhoto.name}`,
        faces: processedFaces
      };

      // Push into existing photo database
      setPhotos((prev) => [newPhotoObj, ...prev]);

      currentIndex++;
      setScanProgress(Math.round((currentIndex / total) * 100));
      setScanStatus((prev) => ({
        ...prev,
        recognizedPeopleCount: peopleRecognized
      }));

    }, 2000); // 2 seconds per image for realistic visual scan feedback
  };

  // --- INTERACTION HANDLERS ---
  
  // Person detail edit name
  const handleUpdatePersonName = (personId: string, newName: string) => {
    if (!newName.trim()) return;
    setPeople((prev) =>
      prev.map((p) => (p.id === personId ? { ...p, name: newName.trim() } : p))
    );
    showToast(`Profil mis à jour : "${newName}"`, 'success');
  };

  // Double clicks or Consult opens photo in viewer
  const handleOpenPhotoViewer = (photo: Photo) => {
    setSelectedPhoto(photo);
  };

  // Swipe logic for Photo Viewer
  const currentPhotoIndex = useMemo(() => {
    if (!selectedPhoto) return -1;
    return filteredPhotos.findIndex((p) => p.id === selectedPhoto.id);
  }, [selectedPhoto, filteredPhotos]);

  const handlePrevPhoto = () => {
    if (currentPhotoIndex > 0) {
      setSelectedPhoto(filteredPhotos[currentPhotoIndex - 1]);
    }
  };

  const handleNextPhoto = () => {
    if (currentPhotoIndex < filteredPhotos.length - 1) {
      setSelectedPhoto(filteredPhotos[currentPhotoIndex + 1]);
    }
  };

  // Associate face to person in PhotoViewer
  const handleAssociateFace = (faceId: string, personId: string | null) => {
    // 1. Update photos array
    setPhotos((prevPhotos) =>
      prevPhotos.map((photo) => {
        const hasFace = photo.faces.some((f) => f.id === faceId);
        if (!hasFace) return photo;

        const updatedFaces = photo.faces.map((f) => {
          if (f.id === faceId) {
            // Decrement previous person's stats if any
            const prevPersonId = f.personId;
            if (prevPersonId) {
              setPeople((prevP) =>
                prevP.map((p) =>
                  p.id === prevPersonId
                    ? {
                        ...p,
                        photosCount: Math.max(0, p.photosCount - 1),
                        facesCount: Math.max(0, p.facesCount - 1)
                      }
                    : p
                )
              );
            }

            // Increment new person's stats if any
            if (personId) {
              setPeople((prevP) =>
                prevP.map((p) =>
                  p.id === personId
                    ? {
                        ...p,
                        photosCount: p.photosCount + 1,
                        facesCount: p.facesCount + 1
                      }
                    : p
                )
              );
            }

            return { ...f, personId };
          }
          return f;
        });

        // Regenerate and return updated photo
        const updatedPhoto = { ...photo, faces: updatedFaces };
        // Sync active viewer photo
        if (selectedPhoto && selectedPhoto.id === photo.id) {
          setSelectedPhoto(updatedPhoto);
        }
        return updatedPhoto;
      })
    );

    const targetPerson = people.find((p) => p.id === personId);
    showToast(
      targetPerson 
        ? `Visage associé avec succès à ${targetPerson.name}`
        : "Association faciale réinitialisée",
      'success'
    );
  };

  // Create new person from photo viewer
  const handleCreateAndAssociateFromViewer = (faceId: string, name: string) => {
    const newPersonId = `p_gen_${Math.random().toString()}`;
    const newPerson: Person = {
      id: newPersonId,
      name,
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150&h=150', // placeholder avatar
      photosCount: 0, // will be incremented inside handleAssociateFace
      facesCount: 0,
      lastSeen: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    // Find and use the cropped face URL as the avatar! Highly cohesive!
    photos.forEach((photo) => {
      const face = photo.faces.find((f) => f.id === faceId);
      if (face) {
        newPerson.avatarUrl = face.croppedUrl;
      }
    });

    setPeople((prev) => [...prev, newPerson]);
    
    // Defer association so people array is updated first
    setTimeout(() => {
      handleAssociateFace(faceId, newPersonId);
    }, 50);
  };

  // Rename modal confirm
  const handleRenameConfirm = (newName: string) => {
    const person = modals.rename.person;
    if (person) {
      handleUpdatePersonName(person.id, newName);
    }
  };

  // Merge profiles confirm
  const handleMergeConfirm = (targetPersonId: string) => {
    const sourcePerson = modals.merge.person;
    const targetPerson = people.find((p) => p.id === targetPersonId);
    
    if (sourcePerson && targetPerson) {
      // 1. Move all photo face associations from source person to target person
      setPhotos((prevPhotos) =>
        prevPhotos.map((photo) => {
          const hasSourceFace = photo.faces.some((f) => f.personId === sourcePerson.id);
          if (!hasSourceFace) return photo;

          const updatedFaces = photo.faces.map((f) => {
            if (f.personId === sourcePerson.id) {
              return { ...f, personId: targetPersonId };
            }
            return f;
          });

          return { ...photo, faces: updatedFaces };
        })
      );

      // 2. Add source person statistics to target person
      setPeople((prevPeople) =>
        prevPeople
          .map((p) => {
            if (p.id === targetPersonId) {
              return {
                ...p,
                photosCount: p.photosCount + sourcePerson.photosCount,
                facesCount: p.facesCount + sourcePerson.facesCount,
              };
            }
            return p;
          })
          .filter((p) => p.id !== sourcePerson.id) // delete source person
      );

      // Close details if we were looking at the deleted source person
      if (selectedPersonId === sourcePerson.id) {
        setSelectedPersonId(null);
        handleTabChange('people');
      }

      showToast(`Profils fusionnés ! "${sourcePerson.name}" fusionné avec "${targetPerson.name}".`, 'success');
    }
  };

  // Delete profile confirm
  const handleDeleteConfirm = () => {
    const target = modals.delete.target;
    const type = modals.delete.type;

    if (!target) return;

    if (type === 'person') {
      // Dissociate faces
      setPhotos((prevPhotos) =>
        prevPhotos.map((photo) => {
          const updatedFaces = photo.faces.map((f) => {
            if (f.personId === target.id) {
              return { ...f, personId: null };
            }
            return f;
          });
          return { ...photo, faces: updatedFaces };
        })
      );

      // Delete from people list
      setPeople((prev) => prev.filter((p) => p.id !== target.id));
      if (selectedPersonId === target.id) {
        setSelectedPersonId(null);
        handleTabChange('people');
      }
      showToast(`Profil supprimé : "${target.name}"`, 'success');
    } else if (type === 'photo') {
      // Remove photo and update people counters
      setPhotos((prev) => prev.filter((p) => p.id !== target.id));
      
      // For each face in this photo, decrement face counts for people
      target.faces.forEach((f: Face) => {
        if (f.personId) {
          setPeople((prev) =>
            prev.map((p) =>
              p.id === f.personId
                ? {
                    ...p,
                    photosCount: Math.max(0, p.photosCount - 1),
                    facesCount: Math.max(0, p.facesCount - 1)
                  }
                : p
            )
          );
        }
      });
      showToast(`Photo supprimée : "${target.name}"`, 'success');
    }
  };

  // Multi selection bulk actions
  const handleBulkExport = () => {
    showToast(`${selectedPhotoIds.length} photo(s) exportée(s) avec succès !`, 'success');
    setSelectedPhotoIds([]);
  };

  const handleBulkDeleteAssociations = () => {
    if (!selectedPersonId) return;

    setPhotos((prevPhotos) =>
      prevPhotos.map((photo) => {
        if (!selectedPhotoIds.includes(photo.id)) return photo;

        const updatedFaces = photo.faces.map((f) => {
          if (f.personId === selectedPersonId) {
            // Decrement person counter
            setPeople((prevP) =>
              prevP.map((p) =>
                p.id === selectedPersonId
                  ? {
                      ...p,
                      photosCount: Math.max(0, p.photosCount - 1),
                      facesCount: Math.max(0, p.facesCount - 1)
                    }
                  : p
              )
            );
            return { ...f, personId: null };
          }
          return f;
        });

        return { ...photo, faces: updatedFaces };
      })
    );

    showToast(`Associations supprimées pour ${selectedPhotoIds.length} photo(s).`, 'success');
    setSelectedPhotoIds([]);
  };

  const handleBulkMove = () => {
    showToast(`${selectedPhotoIds.length} photo(s) déplacée(s) vers un autre dossier avec succès.`, 'info');
    setSelectedPhotoIds([]);
  };

  // Toggle multi select checkbox
  const handleTogglePhotoSelection = (photoId: string) => {
    setSelectedPhotoIds((prev) =>
      prev.includes(photoId) ? prev.filter((id) => id !== photoId) : [...prev, photoId]
    );
  };

  // Toggle select all
  const handleToggleSelectAll = () => {
    if (selectedPhotoIds.length === personPhotos.length) {
      setSelectedPhotoIds([]);
    } else {
      setSelectedPhotoIds(personPhotos.map((p) => p.id));
    }
  };

  return (
    <div id="app-viewport" className="flex h-screen bg-[#F8FAFC] text-slate-800 overflow-hidden font-sans">
      {/* SIDEBAR */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={handleTabChange}
        serverStatus={isScanning ? 'online' : 'online'}
      />

      {/* MAIN CONTAINER */}
      <div id="main-scroll-container" className="flex-1 flex flex-col overflow-y-auto h-screen">
        {/* HEADER */}
        {activeTab === 'dashboard' && (
          <Header
            title="Dashboard FaceSorter"
            subtitle="Vue globale sur l'indexation faciale et les traitements automatisés"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            placeholder="Rechercher des statistiques..."
            showSearch={false}
          />
        )}
        {activeTab === 'scanner' && (
          <Header
            title="Scanner & Analyseur"
            subtitle="Analysez des répertoires locaux d'images et regroupez les profils"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            showSearch={false}
          />
        )}
        {activeTab === 'people' && (
          <Header
            title="Profils Identifiés"
            subtitle="Gérez les personnes détectées et regroupez leurs apparitions"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            placeholder="Rechercher une personne par nom..."
          />
        )}
        {activeTab === 'person-detail' && (
          <Header
            title={selectedPerson ? `Profil : ${selectedPerson.name}` : "Détails du Profil"}
            subtitle="Consultez les apparitions et gérez les associations par lots"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            showSearch={false}
          />
        )}
        {activeTab === 'gallery' && (
          <Header
            title="Galerie Générale"
            subtitle="Naviguez parmi l'ensemble des photos scannées et indexées"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            placeholder="Rechercher une photo par nom de fichier..."
          />
        )}
        {activeTab === 'processing' && (
          <Header
            title="Suivi des Traitements"
            subtitle="Historique des scans par lots de répertoires"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            showSearch={false}
          />
        )}
        {activeTab === 'settings' && (
          <Header
            title="Paramètres Système"
            subtitle="Ajustez les performances et les seuils de classification faciale"
            onNewScan={() => handleTabChange('scanner')}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            showSearch={false}
          />
        )}

        {/* CORE CONTENT LAYOUT */}
        <main id="core-content-frame" className="flex-1 p-8">
          <AnimatePresence mode="wait">
            {/* TAB: DASHBOARD */}
            {activeTab === 'dashboard' && (
              <motion.div
                key="dashboard-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
                className="space-y-8"
              >
                {/* Stats Cards Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  <StatsCard
                    id="stat-photos"
                    title="Photos Scannées"
                    value={stats.totalPhotos}
                    iconName="ImageIcon"
                    description="Images indexées en base"
                    change="+12"
                    changeType="positive"
                  />
                  <StatsCard
                    id="stat-people"
                    title="Personnes Uniques"
                    value={stats.totalPeople}
                    iconName="Users"
                    description="Profils faciaux distincts"
                    change="+2"
                    changeType="positive"
                  />
                  <StatsCard
                    id="stat-folders"
                    title="Dossiers Créés"
                    value={stats.totalFolders}
                    iconName="FolderCheck"
                    description="Répertoires classés"
                    change="Stable"
                    changeType="neutral"
                  />
                  <StatsCard
                    id="stat-speed"
                    title="Vitesse de Calcul"
                    value={stats.avgSpeed}
                    iconName="Clock"
                    description="Moyenne de traitement"
                    change="-0.2s"
                    changeType="positive"
                  />
                </div>

                {/* Sub-layout: Quick overview and promotions */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Left block: Welcome Banner and active summary */}
                  <div className="lg:col-span-2 space-y-6">
                    <div className="bg-linear-to-r from-blue-600 to-indigo-700 p-8 rounded-3xl text-white shadow-lg relative overflow-hidden">
                      {/* Decorative Background bubbles */}
                      <div className="absolute right-0 bottom-0 w-64 h-64 bg-white/5 rounded-full translate-x-20 translate-y-20 blur-2xl pointer-events-none" />
                      <div className="absolute left-1/3 top-10 w-32 h-32 bg-white/5 rounded-full blur-xl pointer-events-none" />

                      <div className="relative space-y-4 max-w-lg z-10">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/15 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-wider">
                          <Sparkles className="w-3.5 h-3.5" /> IA FaceSorter Opérationnelle
                        </span>
                        <h2 className="text-2xl font-extrabold tracking-tight">
                          Classez automatiquement vos photos par reconnaissance faciale
                        </h2>
                        <p className="text-xs text-blue-100/90 leading-relaxed">
                          Sélectionnez un répertoire d'images local, lancez l'analyse par deep-learning, et laissez FaceSorter AI regrouper automatiquement vos proches dans des dossiers dédiés.
                        </p>
                        <button
                          id="dash-btn-scan-start"
                          onClick={() => handleTabChange('scanner')}
                          className="px-5 py-2.5 bg-white hover:bg-slate-50 text-blue-700 font-extrabold text-xs rounded-xl shadow-md transition-all inline-flex items-center gap-1.5"
                        >
                          Lancer un nouveau scan
                        </button>
                      </div>
                    </div>

                    {/* Recently scannned folder list or previews */}
                    <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                          Dernières activités de tri
                        </h4>
                        <button
                          id="dash-link-processing"
                          onClick={() => handleTabChange('processing')}
                          className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1"
                        >
                          Voir l'historique <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="space-y-3">
                        {history.slice(0, 3).map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100/50 transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
                                <FolderCheck className="w-4 h-4" />
                              </div>
                              <div>
                                <span className="block text-xs font-bold text-slate-800 break-all">{item.folderPath}</span>
                                <span className="block text-[10px] text-slate-400 font-medium">{item.date} • {item.photosCount} photos</span>
                              </div>
                            </div>
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              item.status === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                            }`}>
                              {item.status === 'success' ? 'Succès' : 'Échoué'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Right block: Highlighted People summary */}
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 flex flex-col justify-between h-full">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                          <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                            Personnes Détectées ({people.length})
                          </h4>
                          <button
                            id="dash-link-people"
                            onClick={() => handleTabChange('people')}
                            className="text-xs font-bold text-blue-600 hover:underline"
                          >
                            Tout voir
                          </button>
                        </div>

                        {/* Person Avatar Rows */}
                        <div className="space-y-3">
                          {people.slice(0, 4).map((p) => (
                            <div
                              key={p.id}
                              id={`dash-person-${p.id}`}
                              onClick={() => {
                                setSelectedPersonId(p.id);
                                handleTabChange('person-detail');
                              }}
                              className="flex items-center justify-between p-2.5 hover:bg-slate-50 rounded-xl border border-transparent hover:border-slate-100 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-3">
                                <img
                                  src={p.avatarUrl}
                                  alt={p.name}
                                  className="w-8 h-8 rounded-full object-cover border border-slate-200"
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <span className="block text-xs font-bold text-slate-800">{p.name}</span>
                                  <span className="block text-[10px] text-slate-400 font-medium">
                                    {p.photosCount} photos trouvées
                                  </span>
                                </div>
                              </div>
                              <ChevronRight className="w-4 h-4 text-slate-400" />
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-4 border-t border-slate-100">
                        <div className="bg-blue-50/50 p-3 rounded-2xl border border-blue-100/50 flex items-start gap-2.5 text-[10px] text-blue-800 font-medium">
                          <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                          <p>
                            Vos profils sont synchronisés. Utilisez l'outil de fusion s'il y a des doublons.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB: SCANNER */}
            {activeTab === 'scanner' && (
              <motion.div
                key="scanner-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
              >
                <ScanPanel
                  id="scanner-panel-component"
                  settings={settings}
                  onUpdateSettings={setSettings}
                  onStartScan={handleStartScanRequest}
                  isScanning={isScanning}
                  scanProgress={scanProgress}
                  scanStatus={scanStatus}
                />
              </motion.div>
            )}

            {/* TAB: PEOPLE GRID */}
            {activeTab === 'people' && (
              <motion.div
                key="people-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-200/60 shadow-xs">
                  <div className="flex items-center gap-2">
                    <ListFilter className="w-4 h-4 text-slate-400" />
                    <span className="text-xs font-bold text-slate-500 uppercase">Trier par :</span>
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full cursor-pointer">
                      Nombre de photos
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-slate-400">
                    {filteredPeople.length} profils trouvés
                  </span>
                </div>

                {filteredPeople.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                    {filteredPeople.map((person) => (
                      <PersonCard
                        key={person.id}
                        id={`person-card-${person.id}`}
                        person={person}
                        onOpen={(id) => {
                          setSelectedPersonId(id);
                          handleTabChange('person-detail');
                        }}
                        onRename={(p) => setModals((m) => ({ ...m, rename: { isOpen: true, person: p } }))}
                        onMerge={(p) => setModals((m) => ({ ...m, merge: { isOpen: true, person: p } }))}
                        onDelete={(p) => setModals((m) => ({ ...m, delete: { isOpen: true, target: p, type: 'person' } }))}
                      />
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    id="people-empty"
                    title="Aucun profil ne correspond"
                    description="Essayez d'ajuster vos critères de recherche ou de lancer un scan pour indexer plus d'images."
                    actionLabel="Lancer un Scan"
                    onActionClick={() => handleTabChange('scanner')}
                  />
                )}
              </motion.div>
            )}

            {/* TAB: PERSON DETAILS */}
            {activeTab === 'person-detail' && selectedPerson && (
              <motion.div
                key="person-detail-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
                className="space-y-8"
              >
                {/* Back to list trigger */}
                <button
                  id="btn-back-to-people"
                  onClick={() => handleTabChange('people')}
                  className="px-4 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700 shadow-xs transition-colors inline-flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-4 h-4" /> Retour aux profils
                </button>

                {/* Profile Hero Header */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left w-full md:w-auto">
                    <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-slate-100 shadow-xs">
                      <img
                        src={selectedPerson.avatarUrl}
                        alt={selectedPerson.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="space-y-3">
                      {/* Interactive Rename field in-place */}
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                        <input
                          id="detail-name-edit-input"
                          type="text"
                          value={selectedPerson.name}
                          onChange={(e) => handleUpdatePersonName(selectedPerson.id, e.target.value)}
                          className="text-2xl font-extrabold text-slate-900 tracking-tight font-sans bg-transparent border-b border-dashed border-slate-300 hover:border-slate-800 focus:outline-hidden focus:border-blue-600 px-1"
                        />
                        <span className="text-slate-400">
                          <Edit3 className="w-4 h-4" />
                        </span>
                      </div>

                      <div className="flex flex-wrap justify-center md:justify-start gap-4 text-xs font-medium text-slate-500">
                        <span>Nombre de photos : <strong className="text-slate-800">{personPhotos.length}</strong></span>
                        <span>•</span>
                        <span>Vu pour la dernière fois : <strong className="text-slate-800">{selectedPerson.lastSeen}</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Column */}
                  <div className="flex flex-wrap gap-3 w-full md:w-auto justify-center">
                    <button
                      id="detail-btn-rename"
                      onClick={() => setModals((m) => ({ ...m, rename: { isOpen: true, person: selectedPerson } }))}
                      className="px-4 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Renommer
                    </button>
                    <button
                      id="detail-btn-merge"
                      onClick={() => setModals((m) => ({ ...m, merge: { isOpen: true, person: selectedPerson } }))}
                      className="px-4 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <GitMerge className="w-3.5 h-3.5" /> Fusionner
                    </button>
                    <button
                      id="detail-btn-delete"
                      onClick={() => setModals((m) => ({ ...m, delete: { isOpen: true, target: selectedPerson, type: 'person' } }))}
                      className="px-4 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-bold text-rose-700 shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Supprimer le profil
                    </button>
                  </div>
                </div>

                {/* Sub-gallery of person photos */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <h3 className="text-sm font-extrabold text-slate-900 tracking-tight">
                      Galerie d'apparitions ({personPhotos.length} photos)
                    </h3>
                    
                    {/* Select All Toggle */}
                    {personPhotos.length > 0 && (
                      <button
                        id="btn-toggle-select-all"
                        onClick={handleToggleSelectAll}
                        className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        {selectedPhotoIds.length === personPhotos.length ? 'Tout désélectionner' : 'Sélectionner tout'}
                      </button>
                    )}
                  </div>

                  {personPhotos.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                      {personPhotos.map((photo) => {
                        const isSelected = selectedPhotoIds.includes(photo.id);

                        return (
                          <div key={photo.id} className="relative group">
                            {/* Individual select checkbox */}
                            <div className="absolute top-3 left-3 z-20 pointer-events-auto">
                              <input
                                id={`select-photo-${photo.id}`}
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => handleTogglePhotoSelection(photo.id)}
                                className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 bg-white/95 backdrop-blur-xs cursor-pointer shadow-md"
                              />
                            </div>

                            <GalleryCard
                              id={`detail-gallery-card-${photo.id}`}
                              photo={photo}
                              onClick={handleOpenPhotoViewer}
                            />
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <EmptyState
                      id="detail-gallery-empty"
                      title="Aucune photo associée"
                      description="Ce profil n'a aucune photo associée. Vous pouvez associer des visages à cette personne dans la visionneuse."
                      actionLabel="Parcourir la Galerie"
                      onActionClick={() => handleTabChange('gallery')}
                    />
                  )}
                </div>

                {/* FLOATING ACTION BAR FOR MULTI SELECTION */}
                <AnimatePresence>
                  {selectedPhotoIds.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 50 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 50 }}
                      className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-800 text-white rounded-2xl px-6 py-4 shadow-2xl flex items-center gap-6 z-40 max-w-lg w-full"
                    >
                      <div className="flex-1 shrink-0">
                        <span className="block text-xs font-extrabold tracking-wider text-slate-400 uppercase">Sélection active</span>
                        <span className="block text-sm font-bold text-white">{selectedPhotoIds.length} photo(s) sélectionnée(s)</span>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Exporter */}
                        <button
                          id="bulk-btn-export"
                          onClick={handleBulkExport}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
                        >
                          <ExternalLink className="w-3.5 h-3.5" /> Exporter
                        </button>

                        {/* Déplacer */}
                        <button
                          id="bulk-btn-move"
                          onClick={handleBulkMove}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
                        >
                          <Move className="w-3.5 h-3.5" /> Déplacer
                        </button>

                        {/* Supprimer l'association */}
                        <button
                          id="bulk-btn-unlink"
                          onClick={handleBulkDeleteAssociations}
                          className="px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 shadow-md shadow-rose-500/10"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Dissocier
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {/* TAB: GENERAL GALLERY */}
            {activeTab === 'gallery' && (
              <motion.div
                key="gallery-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                {/* Search metadata */}
                <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-200/60 shadow-xs">
                  <div className="flex items-center gap-2">
                    <ListFilter className="w-4 h-4 text-slate-400" />
                    <span className="text-xs font-bold text-slate-500 uppercase">Format :</span>
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full cursor-pointer">
                      Grille standard
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-slate-400">
                    {filteredPhotos.length} photos enregistrées
                  </span>
                </div>

                {filteredPhotos.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {filteredPhotos.map((photo) => (
                      <GalleryCard
                        key={photo.id}
                        id={`general-gallery-card-${photo.id}`}
                        photo={photo}
                        onClick={handleOpenPhotoViewer}
                        size={settings.thumbnailSize}
                      />
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    id="general-gallery-empty"
                    title="Aucune photo trouvée"
                    description="Essayez de modifier votre terme de recherche ou lancez l'indexation d'un nouveau dossier d'images."
                    actionLabel="Analyser un dossier"
                    onActionClick={() => handleTabChange('scanner')}
                  />
                )}
              </motion.div>
            )}

            {/* TAB: PROCESSING LOGS */}
            {activeTab === 'processing' && (
              <motion.div
                key="processing-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
              >
                <HistoryTable
                  id="history-table-component"
                  history={history}
                  onViewDetails={(scan) => showToast(`Scan du dossier: ${scan.folderPath} (${scan.detectedFaces} visages trouvés)`, 'info')}
                />
              </motion.div>
            )}

            {/* TAB: SETTINGS */}
            {activeTab === 'settings' && (
              <motion.div
                key="settings-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.2 }}
              >
                <SettingsPanel
                  id="settings-panel-component"
                  settings={settings}
                  onSave={(newSettings) => {
                    setSettings(newSettings);
                    showToast("Paramètres sauvegardés avec succès !", "success");
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* --- FLOATING & MODAL OVERLAYS --- */}

      {/* PHOTO VIEWER MODAL */}
      <AnimatePresence>
        {selectedPhoto && (
          <PhotoViewer
            photo={selectedPhoto}
            onClose={() => setSelectedPhoto(null)}
            people={people}
            onAssociateFace={handleAssociateFace}
            onCreateAndAssociateFace={handleCreateAndAssociateFromViewer}
            onPrev={currentPhotoIndex > 0 ? handlePrevPhoto : undefined}
            onNext={currentPhotoIndex < filteredPhotos.length - 1 ? handleNextPhoto : undefined}
          />
        )}
      </AnimatePresence>

      {/* RENAME MODAL */}
      <RenamePersonModal
        isOpen={modals.rename.isOpen}
        onClose={() => setModals((m) => ({ ...m, rename: { isOpen: false, person: null } }))}
        currentName={modals.rename.person ? modals.rename.person.name : ''}
        onConfirm={handleRenameConfirm}
      />

      {/* MERGE MODAL */}
      <MergePeopleModal
        isOpen={modals.merge.isOpen}
        onClose={() => setModals((m) => ({ ...m, merge: { isOpen: false, person: null } }))}
        person={modals.merge.person}
        allPeople={people}
        onConfirm={handleMergeConfirm}
      />

      {/* DELETE CONFIRM MODAL */}
      <DeleteConfirmModal
        isOpen={modals.delete.isOpen}
        onClose={() => setModals((m) => ({ ...m, delete: { isOpen: false, target: null, type: 'person' } }))}
        itemName={modals.delete.target ? modals.delete.target.name : ''}
        itemType={modals.delete.type}
        onConfirm={handleDeleteConfirm}
      />

      {/* CONFIRM SCAN MODAL */}
      <ConfirmScanModal
        isOpen={modals.confirmScan.isOpen}
        onClose={() => setModals((m) => ({ ...m, confirmScan: { isOpen: false, folderPath: '', photosCount: 0, photosToScan: [] } }))}
        folderPath={modals.confirmScan.folderPath}
        photosCount={modals.confirmScan.photosCount}
        onConfirm={() => {
          // Trigger the actual simulator process with confirmed path and items!
          runScanSimulation(modals.confirmScan.folderPath, modals.confirmScan.photosToScan);
        }}
      />

      {/* TOAST SYSTEM CONTAINER */}
      <Toast toasts={toasts} onClose={removeToast} />
    </div>
  );
}
